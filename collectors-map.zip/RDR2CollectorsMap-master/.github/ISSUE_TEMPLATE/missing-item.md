---
name: Incorrect Item
about: Incorrect item location
title: 'Incorrect item Cycle: day #'
labels: ''
assignees: ''

---

#### Found a new location? [Use this form here](https://github.com/jeanropke/RDR2CollectorsMap/issues/182)
* What day cycle it is?
* Coordinates or a clear image of the location
* Include the item name

Coordinates can be found by setting the `Show coordinates on click` to `Yes`
