const Layers = {
  itemMarkersLayer: new L.LayerGroup(),
  pinsLayer: new L.LayerGroup(),
  overlaysLayer: new L.LayerGroup(),
  nazarLayer: new L.LayerGroup(),
  oms: null
};
